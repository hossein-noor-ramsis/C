int getCommand(char *command);
