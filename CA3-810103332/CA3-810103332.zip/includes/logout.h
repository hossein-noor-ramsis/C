int logout(SYSTEM *System);
