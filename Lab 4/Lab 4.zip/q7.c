#include <stdio.h>
int function(float cal, float phy, float lab);

int main()
{
  float cal = 18, phy = 17, lab = 19;

  // * miss the third argument which was lab
  printf("average = %f\n", function(cal, phy, lab));
  return 0;
}

int function(float cal, float phy, float lab)
{
  float sum = (cal * 3) + (phy * 2) + (lab * 1);
  float average = sum / 6;
  return average;
}