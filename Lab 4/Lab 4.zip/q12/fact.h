int fact(int x);
